package model;
public class Resource {
 private int id;
 private String resourceName;
 private float consumptionValue;
 public Resource(String resourceName,float consumptionValue){
  this.resourceName=resourceName;
  this.consumptionValue=consumptionValue;
 }
 public int getId(){return id;}
 public String getResourceName(){return resourceName;}
 public float getConsumptionValue(){return consumptionValue;}
}