import java.util.*;import dao.ResourceDAO;import model.Resource;
public class Main{
 public static void main(String[] args){
  Scanner sc=new Scanner(System.in);
  ResourceDAO dao=new ResourceDAO();
  while(true){
   System.out.println("1. Add Resource\n2. View All\n3. Exit");
   int ch=sc.nextInt(); sc.nextLine();
   switch(ch){
    case 1:
     System.out.print("Name: "); String n=sc.nextLine();
     System.out.print("Value: "); float v=sc.nextFloat();
     if(dao.addResource(new Resource(n,v))) System.out.println("Inserted");
     else System.out.println("Failed");
     break;
    case 2:
     for(String s:dao.getAllResources()) System.out.println(s);
     break;
    case 3: System.exit(0);
   }
  }
 }
}