package dao;
import java.sql.*;import java.util.*;import model.Resource;import util.DBConnection;
public class ResourceDAO{
 public boolean addResource(Resource r){
  try{
   Connection con=DBConnection.getConnection();
   PreparedStatement pst=con.prepareStatement("INSERT INTO resources(resource_name,consumption_value) VALUES(?,?)");
   pst.setString(1,r.getResourceName()); pst.setFloat(2,r.getConsumptionValue());
   return pst.executeUpdate()>0;
  }catch(Exception e){System.out.println(e);return false;}
 }
 public List<String> getAllResources(){
  List<String> list=new ArrayList<>();
  try{
   Connection con=DBConnection.getConnection();
   ResultSet rs=con.prepareStatement("SELECT * FROM resources ORDER BY timestamp DESC").executeQuery();
   while(rs.next()){
    list.add(rs.getInt("id")+" | "+rs.getString("resource_name")+" | "+rs.getFloat("consumption_value")+" | "+rs.getString("timestamp"));
   }
  }catch(Exception e){System.out.println(e);}
  return list;
 }
}