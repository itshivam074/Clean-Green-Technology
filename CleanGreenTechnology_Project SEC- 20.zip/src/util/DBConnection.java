package util;
import java.sql.*;
public class DBConnection {
 private static final String URL="jdbc:mysql://localhost:3306/clean_green";
 private static final String USERNAME="root";
 private static final String PASSWORD="";
 public static Connection getConnection(){
  try{return DriverManager.getConnection(URL,USERNAME,PASSWORD);}
  catch(Exception e){System.out.println(e);return null;}
 }
}