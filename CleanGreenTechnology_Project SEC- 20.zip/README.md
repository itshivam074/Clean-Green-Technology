# Clean & Green Technology – Environmental Monitoring System

Java + JDBC project for sustainability resource monitoring.
